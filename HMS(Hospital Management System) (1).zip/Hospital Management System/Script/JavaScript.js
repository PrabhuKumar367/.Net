﻿
const textElement = document.getElementById('text');
const message = "Hello, this is a typing effect on an image!";
let index = 0;

function typeText() {
    if (index < message.length) {
        textElement.textContent += message[index];
        index++;
        setTimeout(typeText, 100);  // Adjust the speed of typing (100ms delay)
    } else {
        textElement.style.opacity = 1; // Make the text visible after typing is complete
    }
}

// Call the function to start the animation
window.onload = () => {
    textElement.style.opacity = 1;  // Initially show the text container
typeText();
};








let currentSlide = 0;
const slides = document.querySelectorAll('.slide')
const slideContainer = document.getElementById('slideContainer');
const totalSlides = slides.length;

function updateSlidePosition() {
    // Update the transform property to show the correct slide
    slideContainer.style.transform = `translateX(-${currentSlide * 100}%)`;
}

document.getElementById('rightArrow').addEventListener('click', function() {
    // Move to the next slide (right)
    if (currentSlide < totalSlides - 1) {
        currentSlide++; // Move to the next slide
        updateSlidePosition();
    }
});

document.getElementById('leftArrow').addEventListener('click', function() {
    // Move to the previous slide (left)
    if (currentSlide > 0) {
        currentSlide--; // Move to the previous slide
        updateSlidePosition();
    }
});




    // Function to toggle the visibility of service details
    function toggleDetails(serviceId) {
        var serviceDetails = document.getElementById(serviceId);
        if (serviceDetails.style.display === 'none' || serviceDetails.style.display === '') {
            serviceDetails.style.display = 'block';
        } else {
            serviceDetails.style.display = 'none';
        }
    }




    // JavaScript to handle form submission (optional)
    document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault();
        alert('Thank you for contacting us! We will get back to you shortly.');
    });



    // JavaScript to handle form submission (optional)
    document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault();
        alert('Thank you for contacting us! We will get back to you shortly.');
    });



/*  Login page start
------------------------------------------------------------------------------------------------------*/

    // Toggle password visibility
    const togglePassword = document.getElementById('toggle-password');
    const passwordField = document.getElementById('password');

    togglePassword.addEventListener('click', function () {
        const type = passwordField.type === 'password' ? 'text' : 'password';
        passwordField.type = type;
        this.classList.toggle('fa-eye-slash');
    });

    document.getElementById('login-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Here you would call your backend authentication API
        if (username === "admin" && password === "password123") {
            alert("Login Successful!");
            window.location.href = "dashboard.html"; // Redirect to dashboard page
        } else {
            alert("Invalid credentials. Please try again.");
        }
    });
/*-----Login page End----------------------------------------------------------------------------------------*/





/*SignUp page End
----------------------------------------------------------------------------------------*/
    // Password validation on form submit
    document.getElementById('signup-form').addEventListener('submit', function(event) {
        event.preventDefault();  // Prevent form submission for validation

        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;

        if (password !== confirmPassword) {
            alert("Passwords do not match. Please try again.");
        } else {
            alert("Signup Successful!");
            window.location.href = "login.html";  // Redirect to login page
        }
    });
/*-----SignUp End page End----------------------------------------------------------------------------------------*/