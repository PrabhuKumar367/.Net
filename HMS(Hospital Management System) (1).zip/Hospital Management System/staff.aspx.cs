﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class staff : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Data.mdf;Integrated Security=True");
        if (conn.State == ConnectionState.Open)
        {
            conn.Close();
        }
        //Drop down me gride value value lane ke liye
        conn.Open();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Record save

        try
        {
            conn.Close();
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "insert into staff values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "')";
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Record saved')</script>");
            SqlDataSource1.SelectCommand = "select * from staff";
            GridView1.DataSourceID = "SqlDataSource1";
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }

        //End Record save
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Record Delete
        try
        {
            conn.Close();
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "delete from staff where staff_id='" + TextBox1.Text + "'";
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Record Deleted')</script>");
            SqlDataSource1.SelectCommand = "select * from staff";
            GridView1.DataSourceID = "SqlDataSource1";
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }

        //End Record Delete
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //To Record Update
        try
        {
            conn.Close();
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "update staff set staff_name='" + TextBox2.Text + "',designation='" + TextBox3.Text + "',contact_number='" + TextBox4.Text + "',email='" + TextBox5.Text + "' ,hospital_id='" + TextBox6.Text + "' where staff_id='" + TextBox1.Text + "'";
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Record Update')</script>");
            // Etna code all search karne liye sath me itna sabhi me laga hai
            SqlDataSource1.SelectCommand = "select * from staff";
            GridView1.DataSourceID = "SqlDataSource1";
            // Etna code all search karne liye sath me
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }

        //End Record Update
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        //All Search
        SqlDataSource1.SelectCommand = "select * from staff";
        GridView1.DataSourceID = "SqlDataSource1";

        //End All Search
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        //Particular search with fill form 
        try
        {

            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "select * from staff where staff_id='" + TextBox1.Text + "'";
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                TextBox1.Text = dr.GetValue(0).ToString();
                TextBox2.Text = dr.GetValue(1).ToString();
                TextBox3.Text = dr.GetValue(2).ToString();
                TextBox4.Text = dr.GetValue(3).ToString();
                TextBox5.Text = dr.GetValue(4).ToString();
                TextBox6.Text = dr.GetValue(5).ToString();
            }
            dr.Close();
            //Particular search
            SqlDataSource1.SelectCommand = "select * from staff where staff_id='" + TextBox1.Text + "'";
            GridView1.DataSourceID = "SqlDataSource1";
            //End Particular search
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }


        //End Particular search with fill form 
    }
}