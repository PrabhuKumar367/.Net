﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class TreatmentReport : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Data.mdf;Integrated Security=True");
        if (conn.State == ConnectionState.Open)
        {
            conn.Close();
        }
        //Drop down me gride value value lane ke liye
        conn.Open();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Particular search
        SqlDataSource1.SelectCommand = "select * from treatment where treatment_id='" + TextBox1.Text + "'";
        GridView1.DataSourceID = "SqlDataSource1";
        //End Particular search
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //All Search
        SqlDataSource1.SelectCommand = "select * from treatment";
        GridView1.DataSourceID = "SqlDataSource1";

        //End All Search
    }
}